package com.pojo_classes;

public class Shop {

}
